By @yGolden Epsilon@w

This is a mutation mod that adds in 25 new mutations to NTT.

Art done by:
 - Myself (GoldenEpsilon#8656)
 - SoScary#2361 (https://twitter.com/nobreadthanks/)
 - smashy#6252	
 - Jsburg#1045
 - tildebee~ ♡#6521
 - Nemo-The-Axolotl#1344
 - Anastas McBeth#1346
 
Sounds done by:
 - mufina#3663


Full list of mutations:

Compressing Fist:   You need to use twice the ammo with each shot, but all your shots do double damage.

Confidence:   At full HP you gain speed, reload speed, and damage.

Duplicators:   Every time you use ammo, you recover 1/3 of it afterwards.

Garment Regenerator:   When you take damage, you heal half of that damage a second later.

Rocket Casings:   Your bullets have their speed/knockback multiplied by 1.25, and the bullets explode (the explosions do less damage and do not break walls, however).

Sloppy Fingers:   You fire at 1.5x speed, but you have reduced accuracy.

Steel Nerves:   You only take damage up to half your max HP each hit.

Unstable DNA:   Reset to level 1, keeping mutations, but you lose half your max HP.

Staked Chest:     Enemies overkilled by bolt weapons create splinters

Shocked Skin:     Shotguns create a blast that pierces based on how powerful it is

Waste Gland:     Explosions create toxic clouds

Scrap Arms:     Bullet ammo drops from enemies when you're carrying a bullet weapon

Toxic Thoughts:     Toxic clouds home in towards enemies

Shattered Skull:     Shells split into more shells when they are fired

Energized Intestines:     Bolts stuck in walls shock nearby enemies

Fractured Fingers:     Enemies killed by explosions explode

Dynamic Calves: You move faster, and when you move you take speed away from enemies relative to how fast you're moving.

Sadism: Every 25 ammo you use (125 for bullet weapons) heals you.

Filtering Teeth: Pickups last longer.

Brain Transfer: All your weapon mutations get rerolled. (Heavy Heart is not included)

Pressurized Lungs: Flames knock back enemies.

Muscle Memory: When you reflect a bullet it targets the nearest enemy, with higher speed and damage.

Double Vision: You have a 1/4 chance to get a duplicate of every bullet you fire.

Thick Head: You get to choose one of your mutations again, making it stronger

Mimicry: At level ultra you get to choose a different mutant's ultra. Not all ultras work.

Neural Network: You get to choose from 4 to 8 (depending on what mods you have loaded (Defpack and NTTE)) mutations that each affect a different type of energy weapon in different ways.

LOMuts ultras:
Stuff that seems ridiculous until you try it with the right setup.
Chicken: Enlightenment - Thrown weapons home
Robot: Fast Food - Temporary buffs when you eat weapons
Eyes: Galactic Style - Telekinesis pulls everything to your cursor
Fish: Adaptable - reaching max ammo uses ammo to give you more max ammo
Crystal: Armory - blades rotate around you when shielded
Melting: Existence - Blood Explosions move towards enemies
Plant: Generalist - You have three snares
YV: DOLLA DOLLA - all ammo costs are halved
Steroids: Intellect - your primary weapon has increased accuracy, your secondary weapon autoaims
Rebel: Union - your allies combine together into a powerful ally
Horror: Fission - Hitting enemies with the rad beam instantly refunds
Rogue: Super Backup - Using portal strike summons friendly IDPD
Skeleton: Reincarnation - Turn into a random character
Frog: Positivity - Bouncing off walls gives you temporary speed boosts, moving fast pushes stuff away

Thanks to the NT discord for answering all my questions and trying to help with balance