With Nuclear Throne Together installed (https://yellowafterlife.itch.io/nuclear-throne-together),
type "/load writhe" intro the console during the character selection screen.