1. Move the palette you want to use to your AppData/local/nuclearthrone/data/defpermissions.mod folder
   (Defpack has to be run at least once on your system for that folder to exist)
2. Open Nuclear Throne Together and load Defpack
3. type "/pimport PALETTE_NAME"